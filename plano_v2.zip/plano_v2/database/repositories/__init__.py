"""Repositórios SQL da aplicação."""
